<?php
/*
Plugin Name: My First Plugin
Description: This is my first plugin! It makes a new admin menu link!
Author: Jayanthan
Version: 1.0
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Include mfp-functions.php
require_once plugin_dir_path(__FILE__) . 'includes/mfp-functions.php';
?>
