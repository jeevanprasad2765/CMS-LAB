<?php

//kill direct access
defined('_JEXEC') || die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;

class PlgContentContentPlugDemo extends CMSPlugin
{
    public function onContentPrepare($context, &$article, &$params, $page = 0)
    {
 //getters
    $doc = Factory::getApplication()->getDocument();
    $wa = $doc->getWebAssetManager();
    $pluginPath = 'plugins/content/' . $this->_name;
    $view = JFactory::getApplication()->input->get('view');
		
		//echo '<br/>the view is '.$view;
           //find each card
    preg_match_all('/{card.*?\/card}/s', $article->text, $matches);

     //an array to store the new divs
     foreach ($matches[0] as $value) {
       //this searches between the card tags to find the body
      //this would be in group 2 of this match.. see RegEx101.com for more info
      preg_match('/(?<={card)(.*?})(.*?)(?={\/card})/s', $value, $cardMatcher);
     $cardBody = $cardMatcher[2];
     //Match the title attribute based on the first group in the previous match
     preg_match('/(?<=title=").*?(?=")/s', $cardMatcher[1], $titleMatch);
     $title = '';
     //if this isn't null, the title attribute must be there
      if ($titleMatch) {
           $title = $titleMatch[0];
      }
     //generate the output
      if ($title == '') {
         //make a card div with no title
     $output = '<div class="card bg-success mb-3 text-light"><div class="card-body">'.$cardBody.'</div></div>';
     } else {
                //make a card div with a span title and a card body div, remember to close both divs.
  $output = '<div class="card bg-primary mb-3 text-light"><span class="card-header">'.$title . '</span><div class="card-body">'. $cardBody.'</div></div>';
            }
            //replace the original card $value with the new $output
            $article->text = str_replace($value, $output, $article->text);
        }
   }
}
