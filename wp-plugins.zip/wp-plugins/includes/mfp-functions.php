<?php
/*
 * Add my new menu to the Admin Control Panel
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Hook the 'admin_menu' action hook to run the function
add_action('admin_menu', 'mfp_Add_My_Admin_Link');

// Function to add a new top-level menu link
function mfp_Add_My_Admin_Link() {
    add_menu_page(
        'My First Page',            // Page title
        'My First Plugin',          // Menu title
        'manage_options',           // Capability
        'mfp-first-plugin',         // Menu slug
        'mfp_Display_Admin_Page',   // Callback function
        'dashicons-admin-generic',  // Icon
        20                          // Position
    );
}

// Function to display the admin page content
function mfp_Display_Admin_Page() {
    include plugin_dir_path(__FILE__) . 'mfp-first-acp-page.php';
}
?>
